## CRUD Requests ##

### Create: **POST** ###

 POST <Host>/<Resource>/?attribute1=val1&attribute2&val2

 e.g: POST localhost/webservice/member/?firstname=Roberto&lastname=Limo

### Read: **GET** ###

 Get one : <Host>/<Resource>/<id>
 Get All:  <Host>/Resource>/
 e.g: GET localhost/webservice/member/ or e.g: GET localhost/webservice/member/1

### Update: **PUT** ###
 
PUT <Host>/<Resource>/<id>?attribute1=val1&attribute2&val2

 e.g: PUT localhost/webservice/member/1?firstname=Roberto&lastname=Limo